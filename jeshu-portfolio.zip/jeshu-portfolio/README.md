# Jeshu's portfolio

Personalized recreation of the Milo canvas: JESHU snake/pixel loading animation, supplied portrait, requested sticker cutouts, nine typewritten cards, draggable stickers and background, drawing palette, undo/redo, guestbook and contact links.

## Preview

Install dependencies with `npm install`, then run `npm run dev -- --port 4173`.

Production output: `npm run build`. `dist/client` is the static website. The included worker and hosting metadata preserve the original template's Sites integration.

## Editing

The card copy and contact URLs are at the top of `src/App.jsx`. Layout styles are in `src/styles.css`. Sticker assets are in `public/assets`; original measured placement data is in `src/stickers.json`.

## Interactions

- Arrow keys, mouse wheel, and chevron controls change cards. The final card returns to the first.
- Drag the background to pan. Ctrl + wheel or a two-finger pinch zooms. Reset view restores the initial framing.
- Drag stickers to reposition them. Their positions persist in the current browser.
- Click the JESHU nameplate to replay the opening animation.
- The pencil opens the drawing palette. Undo, redo, eraser, color and line size work.
- Guestbook notes, drawings and visits are stored in the current browser, not shared between visitors. The arrival panel describes the current visit.
- Email and LinkedIn links use the addresses provided by Jeshu. No additional social profiles are fabricated.

## Asset provenance

Design reference and retained decorative stickers: https://milo.gg/, captured October 11, 2026. The source design and assets retain their owners' rights; follow the source site's terms for reuse. Personal portrait and laptop-sticker photos supplied by Jeshu. Portrait and three sticker extractions prepared with the built-in image editing tool, asking it to remove backgrounds while preserving the supplied subjects. The name typography and loading animation are code-native.

The native Windows compiler could not enumerate parent directories on this host. `scripts/portable-vendor.mjs` and the Babel transform in the Vite configuration provide a reproducible preview/build without that scan.
