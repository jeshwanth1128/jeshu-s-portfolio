import {useState,useRef,useEffect} from 'react';
import stickers from './stickers.json';

const email='mailto:shortcast957@gmail.com';
const linkedin='https://www.linkedin.com/in/pothuganti-jeshwanth-407a2a360/';
const cards=[
 {text:"Yo, I'm Jeshu. I do cool stuff with cool people and cool companies.",cta:"Let's build",href:email,intro:true},
 {text:'I turn curious ideas into things that work.\n\nI build with AI, think like a designer, and create with a startup mindset.'},
 {text:'Part logic. Part creativity. All curiosity.\n\nFrom AI-powered apps to visual stories, I like turning “what if?” into “what’s next?”'},
 {text:'I make technology feel human.\n\nI explore AI, build digital experiences, and craft content that makes people stop scrolling.'},
 {text:"I don't just use tools. I find new ways to use them.\n\nAlways experimenting with AI, design, automation, and ideas that could become something bigger."},
 {text:'Engineer by education. Creator by instinct. Builder by choice.\n\nI move between code, concepts, visuals, and business ideas—because the interesting stuff happens where they meet.'},
 {text:'Curious by nature. Building by design.\n\nAI & experiments.\nDesign & content.\nProducts & code.\nStartup thinking.',cta:'See what I’m creating',href:linkedin},
 {text:"Have an idea? Let's build it.\n\nSomewhere between engineering, creativity, and entrepreneurship—that's where I work best.",cta:'Let’s talk',href:email},
 {text:'PS: The professional side of me lives on LinkedIn.\n\nThe curious side? You’re already here.',cta:'LinkedIn',href:linkedin},
];
const font={J:['00111','00010','00010','00010','00010','10010','01100'],E:['11111','10000','10000','11110','10000','10000','11111'],S:['01111','10000','10000','01110','00001','00001','11110'],H:['10001','10001','10001','11111','10001','10001','10001'],U:['10001','10001','10001','10001','10001','10001','01110']};
const pixels=[...'JESHU'].flatMap((c,l)=>font[c].flatMap((row,y)=>[...row].flatMap((v,x)=>v==='1'?[{x:5+l*6+x,y:6+y}]:[])));
const colors=['#FF3B30','#FF9500','#FFD60A','#34C759','#0A84FF','#5E5CE6','#BF5AF2','#FFFFFF','#000000'];
const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k))??f;}catch{return f;}};
const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch{}};
const css=s=>Object.fromEntries(s.split(';').filter(p=>p.includes(':')).map(p=>{let at=p.indexOf(':');return[p.slice(0,at).trim().replace(/-([a-z])/g,(_,c)=>c.toUpperCase()),p.slice(at+1).trim()];}));
const excluded=[1,4,8,14,16,17,22,25,27,28];
const labels={0:'Laptop',2:'Sun',3:'Bicycle',5:'Drill',6:'Thumbs up',7:'Little dog',9:'Cap',10:'Email me',11:'Water bottle',12:'Sneaker',13:'LEGO',15:'Flag',18:'Phone booth',19:'Star',20:'LinkedIn',21:'Airplane',23:'Headphones',24:'Let’s talk',26:'Camera'};
const custom=(src,label,x,y,w,r=0,h='auto',extra='')=>({src:'/assets/'+src,label,style:`width:${w}px;transform:translateX(${x}px) translateY(${y}px) rotate(${r}deg);`,innerStyle:`height:${h};`,imgStyle:`width:${w}px;max-width:none;display:block;${extra}`});
const customs=[custom('jeshu.png','Jeshu portrait',196,-445,466,0,'522px','transform:translateY(-38px);'),custom('doge.png','Doge with sunglasses',-190,466,180,-8),custom('specs.png','Chasma udaa liye',-435,-100,230,12),custom('adult.png','Responsible Adult (not really)',710,-480,345,-7)];
function Icon({n}){const file={1:'svg-1',2:'svg-2',3:'svg-5',4:'svg-9',5:'eraser',6:'undo',7:'redo'}[n];return <img className="icon" src={`/assets/${file}.svg`} alt="" aria-hidden="true"/>;}
function NameTag({replay}){const ref=useRef();useEffect(()=>{const ctx=ref.current.getContext('2d');ctx.fillStyle='#fff';pixels.forEach(p=>ctx.fillRect((p.x-5)*8+46,(p.y-6)*8+26,7,7));},[]);return <button className="name-tag" aria-label="Replay Jeshu loading animation" onClick={replay}><canvas ref={ref} width="332" height="112" aria-label="JESHU"/></button>;}
function Loader({done}){
 const ref=useRef();
 useEffect(()=>{const ctx=ref.current.getContext('2d');let frame,start;const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const draw=now=>{start??=now;let t=now-start;ctx.clearRect(0,0,800,400);
   const block=(x,y,opacity=1,glow=false)=>{ctx.fillStyle=`rgba(255,255,255,${opacity})`;ctx.shadowColor='#fff';ctx.shadowBlur=glow?12:0;ctx.beginPath();ctx.roundRect(x*20+1,y*20+1,18,18,4);ctx.fill();};
   const fruit=(x,y)=>{ctx.shadowBlur=0;ctx.fillStyle='#ff3b30';ctx.beginPath();ctx.arc(x*20+10,y*20+10,9,0,Math.PI*2);ctx.fill();};
   if(t<1050&&!reduced){let step=Math.floor(t/50);for(let i=0;i<Math.min(step+1,9);i++){let p=step-i;block(9+Math.min(p,10),10-(p>10?Math.min(p-10,4):0),1-i*.06,i===0);}fruit(step<10?10+step:20,step<10?10:5);}
   else{let count=reduced?pixels.length:Math.min(pixels.length,Math.floor((t-1050)/16));pixels.slice(0,count).forEach((p,i)=>block(p.x,p.y,i>count-6?1:.88,i>count-3));if(count<pixels.length)fruit(pixels[count].x,pixels[count].y);}
   t<(reduced?900:3600)?frame=requestAnimationFrame(draw):done();};frame=requestAnimationFrame(draw);return()=>cancelAnimationFrame(frame);
 },[done]);
 return <div className="loader" role="status" aria-label="Loading Jeshu’s portfolio"><div className="loader-grid"/><canvas ref={ref} width="800" height="400"/><span className="sr-only">JESHU</span></div>;
}
function Typewriter({text,active}){
 const [count,setCount]=useState(0);
 useEffect(()=>{if(!active){setCount(0);return;}if(matchMedia('(prefers-reduced-motion: reduce)').matches){setCount(text.length);return;}setCount(0);let i=0;const t=setInterval(()=>{setCount(++i);if(i>=text.length)clearInterval(t);},24);return()=>clearInterval(t);},[text,active]);
 return <div className="typed" aria-label={text}><span aria-hidden="true">{[...text].map((c,i)=><span key={i} style={{opacity:i<count?1:0}}>{c}{i===count-1&&<i className="caret"/>}</span>)}</span></div>;
}
function Nav({index,change,mobile=false}){return <nav className={`navigation ${mobile?'mobile-nav':'desktop-nav'}`} aria-label="Portfolio slides"><button aria-label="Previous slide" disabled={!index} onClick={()=>change(index-1)}><Icon n="1"/></button><span className="count">{index+1}<span>/</span>9</span><button aria-label={index===8?'Go to first slide':'Next slide'} onClick={()=>change(index===8?0:index+1)}><Icon n={index===8?'1':'2'}/></button></nav>;}
function Sticker({item,id,scale,activate}){
 const [offset,setOffset]=useState(()=>read('sticker-'+id,{x:0,y:0}));const drag=useRef();const base=css(item.style);const label=item.label??labels[id];
 useEffect(()=>{const reset=()=>{setOffset({x:0,y:0});save('sticker-'+id,{x:0,y:0});drag.current=null;};addEventListener('jeshu-reset-layout',reset);return()=>removeEventListener('jeshu-reset-layout',reset);},[id]);
 return <div className="sticker" role="button" tabIndex={0} aria-label={label} style={{...base,zIndex:id==='c0'?0:200,transform:`${base.transform} translate(${offset.x}px,${offset.y}px)`}}
 onPointerDown={e=>{e.stopPropagation();e.currentTarget.setPointerCapture(e.pointerId);drag.current={x:e.clientX,y:e.clientY,start:offset,moved:false};}}
 onPointerMove={e=>{if(!drag.current)return;let dx=(e.clientX-drag.current.x)/scale,dy=(e.clientY-drag.current.y)/scale;if(Math.abs(dx)+Math.abs(dy)>5)drag.current.moved=true;setOffset({x:drag.current.start.x+dx,y:drag.current.start.y+dy});}}
 onPointerUp={e=>{e.stopPropagation();if(!drag.current)return;drag.current.moved?save('sticker-'+id,offset):activate(id);drag.current=null;}}
 onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activate(id);}}}>
 <div style={{width:'100%',overflow:'hidden',...css(item.innerStyle)}}><img src={item.src} alt={label} draggable="false" style={css(item.imgStyle)}/></div></div>;
}
function Guestbook({dialog=false,close}){
 const [notes,setNotes]=useState(()=>read('jeshu-notes',[]));const [note,setNote]=useState(''),[name,setName]=useState('');
 useEffect(()=>{const sync=()=>setNotes(read('jeshu-notes',[]));addEventListener('jeshu-notes-updated',sync);return()=>removeEventListener('jeshu-notes-updated',sync);},[]);
 const remove=()=>{const next=notes.slice(0,-1);setNotes(next);save('jeshu-notes',next);dispatchEvent(new Event('jeshu-notes-updated'));};
 return <section className={`guestbook ${dialog?'in-dialog':''}`} aria-label="Guestbook"><header>Guestbook{dialog&&<button autoFocus onClick={close} aria-label="Close guestbook">Close</button>}</header><div className="book-pages"><div className="book-left"><small>{notes.at(-1)?.date??'Hey, you made it.'}</small><p>{notes.at(-1)?.note??'Leave a little something.'}</p><span>— {notes.at(-1)?.name??'Jeshu'}</span></div><form onSubmit={e=>{e.preventDefault();if(!name.trim()||!note.trim())return;const next=[...notes,{name:name.trim(),note:note.trim(),date:new Date().toLocaleDateString('en',{month:'short',day:'numeric',year:'numeric'})}].slice(-30);setNotes(next);save('jeshu-notes',next);dispatchEvent(new Event('jeshu-notes-updated'));setName('');setNote('');}}><textarea value={note} onChange={e=>setNote(e.target.value)} maxLength={240} aria-label="Leave a note" placeholder="Leave a note for everyone who visits…"/><div><input value={name} onChange={e=>setName(e.target.value)} maxLength={40} aria-label="Your name" placeholder="your name"/><button disabled={!name.trim()||!note.trim()}>post</button></div><small>saved on this device {notes.length>0&&<button type="button" className="remove-note" onClick={remove}>remove my last note</button>}</small></form></div></section>;
}
function Arrivals(){return <div className="arrivals" aria-label="Website arrivals"><header>Website arrivals<small>YOUR VISIT</small></header><p>Welcome to Jeshu’s little corner.</p><div className="columns"><span>TIME</span><span>FROM</span><span>STATUS</span></div><div className="arrival-row">{[new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'}),'YOUR DEVICE','LANDED'].map((s,i)=><span key={i}>{[...s].map((c,j)=><b key={j} style={{animationDelay:`${j*40}ms`}}>{c}</b>)}</span>)}</div><div className="empty-row"/><div className="empty-row"/><div className="empty-row"/></div>;}
export function App(){
 const [loaded,setLoaded]=useState(false),[index,setIndex]=useState(0),[size,setSize]=useState({w:innerWidth,h:innerHeight}),[zoom,setZoom]=useState(1),[pan,setPan]=useState({x:0,y:0});
 const [drawing,setDrawing]=useState(false),[color,setColor]=useState(colors[0]),[pen,setPen]=useState(20),[erasing,setErasing]=useState(false),[modal,setModal]=useState(null),[toast,setToast]=useState('');
 const [strokes,setStrokes]=useState(()=>read('jeshu-lines',[])),[redo,setRedo]=useState([]),[visits]=useState(()=>read('jeshu-visits',0)+1);
 const canvas=useRef(),motion=useRef(),line=useRef(),wheel=useRef(0),points=useRef(new Map()),pinch=useRef();const done=useRef(()=>setLoaded(true)).current;
 const boardWidth=size.w<640?size.w-48:544;
 const scale=boardWidth/672*.6*zoom;
 const ctaFactor=boardWidth<=240?.6:boardWidth<=280?.68:boardWidth<=320?.75:boardWidth<=380?.82:boardWidth<=460?.9:1;
 useEffect(()=>{const resize=()=>setSize({w:innerWidth,h:innerHeight});addEventListener('resize',resize);save('jeshu-visits',visits);return()=>removeEventListener('resize',resize);},[visits]);
 useEffect(()=>{const key=e=>{if(/INPUT|TEXTAREA/.test(e.target.tagName))return;if(e.key==='Escape'){setDrawing(false);setModal(null);}if(['ArrowUp','ArrowRight','ArrowDown','ArrowLeft'].includes(e.key)){e.preventDefault();setIndex(i=>Math.max(0,Math.min(8,i+(['ArrowUp','ArrowRight'].includes(e.key)?1:-1))));}if(e.key==='Home')setIndex(0);};addEventListener('keydown',key);return()=>removeEventListener('keydown',key);},[]);
 useEffect(()=>{if(!loaded)return;let c=canvas.current,ctx=c.getContext('2d'),dpr=devicePixelRatio;c.width=size.w*dpr;c.height=size.h*dpr;ctx.scale(dpr,dpr);ctx.lineCap='round';ctx.lineJoin='round';strokes.forEach(s=>{ctx.strokeStyle=s.color;ctx.lineWidth=s.width*scale;ctx.beginPath();s.points.forEach((p,i)=>{let x=size.w/2+pan.x+(p.x-336)*scale,y=size.h/2+pan.y+(p.y-252)*scale;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();});},[strokes,size,scale,pan,loaded]);
 useEffect(()=>save('jeshu-lines',strokes),[strokes]);useEffect(()=>{if(!toast)return;let t=setTimeout(()=>setToast(''),2000);return()=>clearTimeout(t);},[toast]);
 const coord=e=>({x:(e.clientX-size.w/2-pan.x)/scale+336,y:(e.clientY-size.h/2-pan.y)/scale+252});
 const activate=id=>{if(id===10)location.href=email;else if(id===20)window.open(linkedin,'_blank','noopener,noreferrer');else if(id===24)setModal('contact');else if(id==='c1')setToast('Such portfolio. Much cool.');else if(id==='c2')setToast('Chasma udaa liye.');else if(id==='c3')setToast('Responsible adult. Not really.');else if(id===6)setToast('Right back at you!');};
 const release=e=>{points.current.delete(e.pointerId);pinch.current=null;motion.current=null;line.current=null;};
 return <><div inert={modal ? true : undefined} className={`portfolio ${loaded?'ready':''} ${drawing?'drawing':''}`}
 onPointerDown={e=>{if(e.target.closest('button,a,input,textarea,.sticker,.card,.guestbook,.arrivals'))return;e.currentTarget.setPointerCapture(e.pointerId);points.current.set(e.pointerId,{x:e.clientX,y:e.clientY});if(points.current.size===2){let[a,b]=[...points.current.values()];pinch.current={distance:Math.hypot(a.x-b.x,a.y-b.y),zoom};motion.current=null;return;}if(drawing){let p=coord(e);if(erasing){setStrokes(ss=>ss.filter(s=>!s.points.some(q=>Math.hypot(p.x-q.x,p.y-q.y)<40)));return;}line.current={color,width:pen,points:[p,{x:p.x+.1,y:p.y+.1}]};setStrokes(ss=>[...ss,line.current]);setRedo([]);}else motion.current={x:e.clientX,y:e.clientY,pan};}}
 onPointerMove={e=>{if(points.current.has(e.pointerId))points.current.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pinch.current&&points.current.size===2){let[a,b]=[...points.current.values()];setZoom(Math.max(.5,Math.min(3,pinch.current.zoom*Math.hypot(a.x-b.x,a.y-b.y)/pinch.current.distance)));return;}if(line.current){line.current={...line.current,points:[...line.current.points,coord(e)]};setStrokes(ss=>[...ss.slice(0,-1),line.current]);}else if(motion.current)setPan({x:motion.current.pan.x+e.clientX-motion.current.x,y:motion.current.pan.y+e.clientY-motion.current.y});}}
 onPointerUp={release} onPointerCancel={release}
 onWheel={e=>{if(modal||drawing)return;if(e.ctrlKey||e.metaKey)setZoom(z=>Math.max(.5,Math.min(3,z-e.deltaY*.003)));else if(Math.abs(e.deltaY)>15&&Date.now()-wheel.current>650){wheel.current=Date.now();setIndex(i=>Math.max(0,Math.min(8,i+(e.deltaY>0?1:-1))));}}}>
 <div className="background-grid" style={{backgroundSize:`${24*zoom}px ${24*zoom}px`,backgroundPosition:`calc(50% + ${pan.x}px) calc(50% + ${pan.y}px)`}}/>
 <canvas ref={canvas} className="drawing-canvas" aria-hidden="true"/>
 <main className="world" style={{'--control-adjust':672/boardWidth,'--cta-adjust':672/boardWidth*ctaFactor,transform:`translate(-50%,-50%) translate(${pan.x}px,${pan.y}px) scale(${scale})`}} aria-label="Jeshu portfolio">
 {stickers.map((item,i)=>excluded.includes(i)?null:<Sticker key={i} item={item} id={i} scale={scale} activate={activate}/>)}
 {customs.map((item,i)=>{const positioned=size.h<650&&i===0?custom('jeshu.png',item.label,205,-245,320,0,'360px','transform:translateY(-20px);'):size.w<640&&i===2?custom('specs.png',item.label,-295,-260,230,12):size.w<640&&i===3?custom('adult.png',item.label,600,-480,345,-7):item;return <Sticker key={'c'+i} item={positioned} id={'c'+i} scale={scale} activate={activate}/>;})}
 <NameTag replay={()=>setLoaded(false)}/>
 <button className="visitor-badge" onClick={()=>setToast('Welcome to my corner of the internet.')}>you’re visitor {visits} on this device</button>
 <div className="book-position"><Guestbook/></div><div className="arrivals-position"><Arrivals/></div>
 <div className="deck">{cards.map((c,i)=>{let d=(i-index+9)%9;return <article key={i} className={`card ${d===0?'active':''} ${c.intro?'intro':''}`} aria-hidden={d!==0} inert={d?true:undefined} style={{zIndex:100-d*10,opacity:Math.max(.2,1-d*.1),transform:`translateY(${[0,10,25,45,70,100,135,175,220][d]}px) scale(${1-d*.02})`,filter:d>2?`blur(${Math.min(3,Math.floor(d/2))}px)`:'none'}}><div className="card-inside"><Typewriter text={c.text} active={d===0&&loaded}/>{c.cta&&<a className="cta" href={c.href} target={c.href.startsWith('https')?'_blank':undefined} rel="noreferrer">{c.cta}<Icon n="3"/></a>}</div></article>;})}<Nav index={index} change={setIndex}/></div>
 </main><Nav mobile index={index} change={setIndex}/>
 <button className={`draw-toggle ${drawing?'selected':''}`} aria-label={drawing?'Done drawing':'Draw on the wall'} onClick={()=>setDrawing(v=>!v)}>{drawing?<span>×</span>:<Icon n="4"/>}</button>
 {drawing&&<aside className="drawing-toolbar" aria-label="Drawing tools"><div className="palette">{colors.map(c=><button key={c} aria-label={`Color ${c}`} aria-pressed={color===c&&!erasing} style={{background:c}} onClick={()=>{setColor(c);setErasing(false);}}/>)}<button aria-label="Eraser" aria-pressed={erasing} onClick={()=>setErasing(v=>!v)}><Icon n="5"/></button><button aria-label="Undo" disabled={!strokes.length} onClick={()=>{setRedo(rr=>[...rr,strokes.at(-1)]);setStrokes(ss=>ss.slice(0,-1));}}><Icon n="6"/></button><button aria-label="Redo" disabled={!redo.length} onClick={()=>{setStrokes(ss=>[...ss,redo.at(-1)]);setRedo(rr=>rr.slice(0,-1));}}><Icon n="7"/></button></div><label>size<input type="range" min="2" max="35" value={pen} onChange={e=>setPen(+e.target.value)}/></label><p>Draw on my website’s background.<br/>Your lines stay on this device.</p></aside>}
 <button className="reset-view" onClick={()=>{setPan({x:0,y:0});setZoom(1);dispatchEvent(new Event('jeshu-reset-layout'));}}>reset view</button><button className="guestbook-open" onClick={()=>setModal('guestbook')}>guestbook</button>{toast&&<div className="toast" role="status">{toast}</div>}
 </div>
 {modal&&<div className="modal-backdrop" onClick={()=>setModal(null)}><div className="dialog" role="dialog" aria-modal="true" aria-label={modal==='guestbook'?'Guestbook':'Let’s talk'} onClick={e=>e.stopPropagation()}>{modal==='guestbook'?<Guestbook dialog close={()=>setModal(null)}/>:<><button autoFocus className="dialog-close" aria-label="Close contact" onClick={()=>setModal(null)}>×</button><h2>Have an idea?<br/>Let’s build it.</h2><a href={email}>shortcast957@gmail.com<Icon n="3"/></a><a href={linkedin} target="_blank" rel="noreferrer">The professional side of me<Icon n="3"/></a></>}</div></div>}
 {!loaded&&<Loader done={done}/>}
 </>;
}

