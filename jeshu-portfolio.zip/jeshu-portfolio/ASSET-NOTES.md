# Personalized assets

Prepared using the built-in image editing tool. Final project assets are `public/assets/jeshu.png`, `public/assets/doge.png`, `public/assets/specs.png`, and `public/assets/adult.png`.

The user's second supplied photo is the portrait edit target. The laptop sticker photo is the target for the other three. Decorative objects and control icons were captured from the rendered Milo reference and stored locally.

## Prompt set

**Portrait:** Background extraction. Remove only green background and bedding; preserve the person's exact face, hairstyle, expression, skin tone, striped shirt and photograph as closely as possible. Neat head-and-shoulders photographic sticker with thin solid white outline following hair and shoulders. Entire hair visible. No stylization, face change, retouch or substitute person. Transparent background.

**Doge:** Extract only the Doge dog with black pixel sunglasses from the laptop photo's bottom right. Keep its white die-cut border, warm tan dog face and sunglasses. Remove laptop and all other objects. Crisp front-facing single sticker on a transparent background.

**Specs:** Extract only the illustrated man with black sunglasses and orange/yellow CHASMA UDAA LIYE caption. Preserve illustration, caption and white border. Remove laptop and other objects; restore crisp legible front-facing sticker on a transparent background.

**Responsible Adult:** Extract only the mint-green rectangular Responsible Adult (not really) sticker. Preserve yellow smiley, green square, black text, For Emergency Use Only label, barcode, green double border and white edge. Flatten perspective and restore legibility. Isolated transparent background.

**Responsible Adult refinement:** Remove all gray/black background and glow outside the existing rounded rectangular sticker. Keep its green frame, white rounded paper, smiley, typography and barcode unchanged. Do not redraw. Fully transparent exterior alpha and a modest transparent margin.
