import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createRequire} from 'node:module';
import path from 'node:path';
// Build the three CommonJS browser packages without the native compiler.
const resolve=createRequire(import.meta.url), modules=[], ids=new Map();
const production=process.argv.includes('--production');
function add(file){if(ids.has(file))return ids.get(file);const id=modules.length;ids.set(file,id);modules.push(null);let code=readFileSync(file,'utf8');const branches=code.match(/if \(process.env.NODE_ENV === ['"]production['"]\) \{\s*module.exports = require\(['"]([^'"]+)['"]\);\s*\} else \{\s*module.exports = require\(['"]([^'"]+)['"]\);\s*\}/);if(branches)code=`module.exports = require(${JSON.stringify(branches[production?1:2])});`;const req=createRequire(file);const dependencies={};for(const match of code.matchAll(/require\(['"]([^'"]+)['"]\)/g))dependencies[match[1]]=add(req.resolve(match[1]));modules[id]={code,dependencies};return id;}
const react=add(resolve.resolve('react')),client=add(resolve.resolve('react-dom/client'));
const table=modules.map(m=>`[function(require,module,exports,process){\n${m.code}\n},${JSON.stringify(m.dependencies)}]`).join(',\n');
mkdirSync('src/vendor',{recursive:true});
writeFileSync('src/vendor/browser-react.mjs',`const modules=[${table}],cache={};\nfunction load(id){if(cache[id])return cache[id].exports;const module={exports:{}};cache[id]=module;const [fn,deps]=modules[id];fn(name=>load(deps[name]),module,module.exports,{env:{NODE_ENV:'${production?'production':'development'}'}});return module.exports;}\nconst React=load(${react});const client=load(${client});\nexport default React;export const {useState,useEffect,useRef,useMemo,useCallback,createElement,Fragment}=React;export const {createRoot,hydrateRoot}=client;`);
console.log('Portable browser dependencies prepared.');
