# Design QA

final result: passed

## Source and evidence

- Reference: https://milo.gg/, captured October 11, 2026.
- Source visual truth: `qa/reference-desktop.png`, `qa/reference-mobile.png`.
- Rendered production: http://localhost:4174/.
- Implementation screenshots: `qa/desktop.png`, `qa/mobile.png`, `qa/compact.png`.
- Full-view comparison: `qa/comparison-desktop.png`, `qa/comparison-mobile.png`.
- Focused typography/card/stack comparison: `qa/comparison-card.png`.
- State: card 1 of 9, typing completed, clean background, initial canvas position.
- Desktop: both 1440 × 900 pixels and CSS viewport; phone: both 390 × 844 pixels and CSS viewport. Screenshot files are 1:1; no density scaling was applied to comparison files. Compact preview additionally checked at 615 × 532.

## Findings and comparison history

1. [P2, fixed] External SVG icons inherited black stroke and disappeared against the background. Applied white filtering, corrected the original source icon mapping, and recaptured. Navigation arrows, pencil, eraser and undo/redo are visible in the final rendered page.
2. [P2, fixed] Original card control dimensions were measured in the source's 544/342 px internal card, while the implementation uses a normalized 672 px board. Added separate control/CTA scaling so desktop navigation and CTA sizes match the source, without changing typography or sticker geometry. Desktop central card is 326.4 × 244.8 px at (556.8, 327.6); phone is 205.2 × 153.9 px at (92.4, 345.05), matching measured source dimensions and placement.
3. [P2, fixed] Inactive CTA buttons produced blurred gray shapes in the lower stack. Inactive card content is now hidden while the source's nine transforms, borders, opacity steps and blur remain. The final focused card comparison shows clean layers; no background CTA shapes remain.
4. [P2, fixed] Long CTA-bearing card copy approached the button region. Shifted non-intro CTA-card copy upward by 26 board pixels. Measured all nine full text layouts: maximum text height 321 px, available inner height 392 px. The intro remains in its source-aligned position.
5. [P2, fixed] Personal stickers were partly outside the narrow phone framing. Repositioned the specs and Responsible Adult stickers on narrow viewports. All three personal stickers and the face are visible at 390 × 844. At short viewports the portrait scales down to retain the face above the card; `qa/compact.png` shows the full hair, eyes and smile.

The final comparison was performed after fixes 1–4; phone capture includes fix 5. Source and implementation were opened together as full-view and focused comparison images. No actionable P0/P1/P2 differences remain within the personalized target.

## Required fidelity surfaces

- **Fonts/typography:** same ui-monospace stack used by source cards; intro 5.5% of normalized card width, body 4.2%, line-height 1.625; typewriter animation preserves final text wrapping. Pixel nameplate and loading name now read JESHU.
- **Spacing/layout:** exact 4:3 card geometry, central placement, internal 8% padding, original sticker coordinate data, stack offsets 0/10/25/45/70/100/135/175/220, descending scale and bottom origins. Control sizes are separately normalized. Phone navigation remains pinned to the bottom.
- **Colors/tokens:** black canvas and cards, white borders/text, 24 px grid at initial zoom, original drawing palette. Personal assets supply their original colors.
- **Image quality/assets:** source decorative assets are local files; personal portrait, Doge, specs man and Responsible Adult extracted from supplied photos with transparent backgrounds. No source URL hotlinks, stand-in boxes or drawn substitute photos. Source-only people/personal photos are intentionally omitted.
- **Copy/content:** user-provided opening and biography used; email and LinkedIn are user-supplied. Original founder/revenue/customer claims were not transferred. CTA language is personalized. No invented Instagram/GitHub account.

## Intentional personalization and functional boundaries

- Jeshu replaces Milo; his portrait and three stickers replace the source's personal imagery.
- Existing public visitor graffiti was not copied; drawing starts with a clean grid. Newly drawn lines stay in the current browser.
- Guestbook, sticker offsets and visit count are browser-local; the UI says so. Arrival panel describes the current device's visit and does not claim shared live tracking.
- Source contact CTAs open Jeshu's email/LinkedIn or his contact panel instead of Milo's services.
- The loader recreates the snake/red-food/pixel-name sequence; the name path is adapted to JESHU, not a literal copy of the source's name path.

## Browser checks

- All nine next/previous card transitions and final-card return to first exercised.
- All complete card texts measured for clipping.
- Drawing stroke, Undo and Redo exercised; temporary test line removed.
- Guestbook note added through the UI, observed on the page, then removed through its own control.
- Email and LinkedIn hrefs inspected in the rendered contact dialog; no email sent.
- Sticker drag confirmed by changed DOM translation; reset restored original position.
- Canvas pan confirmed by changed world translation; reset restored initial view.
- Phone control positions verified: 32 px navigation buttons at y=780–812 in the 844 px viewport.
- Opening animation and replay observed in the browser.
- No missing/broken images. Production browser console checked: no warning/error entries.
- Production build passed. All four included hosting/worker tests passed.

## Follow-up polish

- [P3] Full motion timing has not been frame-for-frame compared with Milo's implementation; the personalized opening follows the observed visual sequence.
- [P3] Physical two-finger pinch was not tested on phone hardware. The pointer-based pinch path is implemented.

## Implementation checklist

- Complete. Keep the preview running for review.
- Shared visitor data would require a separate backend; it is not part of this local version.

final result: passed
