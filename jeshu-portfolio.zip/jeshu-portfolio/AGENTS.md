# Prototype Instructions

## Jeshu portfolio design contract

Match https://milo.gg/ closely: black grid canvas, floating cutout stickers, centered 4:3 nine-card stack, mono typewriter copy, double-chevron navigation, and pixel snake/name loading sequence. Do not replace this with a conventional landing page, gradient hero, or generic feature cards.

Name is Jeshu. The supplied striped-shirt photo is his portrait. Include Doge sunglasses, Chasma Udaa Liye, and Responsible Adult stickers from the supplied laptop photo. Keep source decorative objects; replace source-specific people and the nameplate with Jeshu's material. Use the bio provided in this conversation, email shortcast957@gmail.com, and verified LinkedIn URL in App.jsx. Do not invent achievements or additional social accounts.

The current guestbook, drawings, sticker positions, and visit badge are browser-local. The arrival panel describes the current visit only. Keep this distinction visible unless a real shared backend is added.

Windows preview uses a portable CommonJS vendor builder and Babel JSX conversion because the native esbuild dependency scan is denied by the host even after read permission is granted. Keep npm dev/build scripts functional; build emits the original Sites-ready output structure.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.
