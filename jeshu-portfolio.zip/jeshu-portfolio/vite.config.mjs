import { defineConfig } from "vite";
import {transformSync,types as t} from '@babel/core';
import path from 'node:path';
function textChild(value){return value.split(/\r\n|\n|\r/).map((line,i,lines)=>{line=line.replace(/\t/g,' ');if(i)line=line.replace(/^ +/,'');if(i!==lines.length-1)line=line.replace(/ +$/,'');return line;}).filter(Boolean).join(' ');}
const jsx={visitor:{
  JSXFragment:{exit(p){p.replaceWith(t.callExpression(t.memberExpression(t.identifier('React'),t.identifier('createElement')),[t.memberExpression(t.identifier('React'),t.identifier('Fragment')),t.nullLiteral(),...p.node.children.map(child).filter(Boolean)]));}},
  JSXElement:{exit(p){const n=p.node;const tag=n.openingElement.name;const name=tag.type==='JSXIdentifier'?(tag.name[0]===tag.name[0].toLowerCase()?t.stringLiteral(tag.name):t.identifier(tag.name)):t.memberExpression(t.identifier(tag.object.name),t.identifier(tag.property.name));const props=n.openingElement.attributes.map(a=>a.type==='JSXSpreadAttribute'?t.spreadElement(a.argument):t.objectProperty(t.stringLiteral(a.name.name),!a.value?t.booleanLiteral(true):a.value.type==='JSXExpressionContainer'?a.value.expression:a.value));p.replaceWith(t.callExpression(t.memberExpression(t.identifier('React'),t.identifier('createElement')),[name,props.length?t.objectExpression(props):t.nullLiteral(),...n.children.map(child).filter(Boolean)]));}}
}};
function child(n){if(n.type==='JSXText'){const value=textChild(n.value);return value?t.stringLiteral(value):null;}if(n.type==='JSXExpressionContainer')return n.expression.type==='JSXEmptyExpression'?null:n.expression;return n;}

export default defineConfig({
  build: {
    outDir: "dist/client",
    minify: false,
    cssMinify: false,
  },
  esbuild: false,
  resolve: { alias: [{find:/^react(?:-dom\/client)?$/,replacement:path.resolve('src/vendor/browser-react.mjs')}] },
  optimizeDeps: {
    noDiscovery: true,
    include: [],
  },
  server: {
    host: "0.0.0.0",
    allowedHosts: ["terminal.local"],
    warmup: {
      clientFiles: ["./src/main.jsx"],
    },
  },
  plugins: [{name:'portable-jsx',enforce:'pre',transform(code,id){if(!id.endsWith('.jsx'))return;return transformSync(`import React from 'react';\n${code.replace(/^import React from [^;]+;\s*/,'')}`,{babelrc:false,configFile:false,parserOpts:{plugins:['jsx']},plugins:[jsx],sourceMaps:false}).code;}}],
});
